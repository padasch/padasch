---
title: Hydra
type: page
---

### Motto

Cut off one head and two will take their place
